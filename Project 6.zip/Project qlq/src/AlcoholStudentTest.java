import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class AlcoholStudentTest {

    private Alcohol vodka;
    private Alcohol whiskey;
    private Alcohol gin;

    @Before
    public void setUp() {
        vodka = new Alcohol("Vodka", Size.SMALL, false);
        whiskey = new Alcohol("Whiskey", Size.MEDIUM, true);
        gin = new Alcohol("Gin", Size.LARGE, true);
    }

    @Test
    public void testCalcPrice() {
        assertEquals(2.0, vodka.calcPrice(), 0.01);
        assertEquals(3.6, whiskey.calcPrice(), 0.01);
        assertEquals(4.0, gin.calcPrice(), 0.01);
    }

    @Test
    public void testIsOfferedInWeekend() {
        assertFalse(vodka.isOfferedInWeekend());
        assertTrue(whiskey.isOfferedInWeekend());
        assertTrue(gin.isOfferedInWeekend());
    }

    @Test
    public void testSetOfferedInWeekend() {
        vodka.setOfferedInWeekend(true);
        assertTrue(vodka.isOfferedInWeekend());
        assertTrue(gin.isOfferedInWeekend());
    }

    @Test
    public void testToString() {
    	assertTrue(vodka.toString().contains(vodka.getName()));
		assertTrue(vodka.toString().contains(String.valueOf(vodka.calcPrice())));
		assertTrue(vodka.toString().contains(vodka.getSize().toString()));
    }

    @Test
    public void testEquals() {
        Alcohol vodka2 = new Alcohol("Vodka", Size.SMALL, false);
        Alcohol whiskey2 = new Alcohol("Whiskey", Size.MEDIUM, true);
        Alcohol gin2 = new Alcohol("Gin", Size.LARGE, true);
        Alcohol gin3 = new Alcohol("Gin", Size.LARGE, false);

        assertTrue(vodka.equals(vodka2));
        assertTrue(whiskey.equals(whiskey2));
        assertTrue(gin.equals(gin2));
        assertFalse(gin.equals(gin3));
    }

}