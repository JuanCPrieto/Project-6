
public interface OrderInterface 
{
	 boolean isWeekend();
	 Beverage getBeverage(int itemNo);
	 void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup);
	 void addNewBeverage(String bevName, Size size);
	 void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein);
	 double calcOrderTotal();
	 int findNumOfBeveType(Type type);
	
}
