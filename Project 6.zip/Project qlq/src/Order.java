/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: 05/05/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan_Prieto__
*/
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Order implements OrderInterface, Comparable<Order> 
{
    private int orderNumber;
    private int orderTime;
    private Day orderDay;
    private Customer customer;
    private List<Beverage> beverages;
    
    public Order(int orderTime, Day orderDay, Customer customer) 
    {
        this.orderNumber = getOrderNumber();
        this.orderTime = orderTime;
        this.orderDay = orderDay;
        this.customer = customer;
        this.beverages = new ArrayList<>();
    }
    
    
    public double calcOrderTotal()
    {
    	double total = 0;

    	for (Beverage bev : beverages) 
    	{
    		total += bev.calcPrice();
    	}

    	return total;
    }
    
    
    public void addNewBeverage(String bevName, Size size)
    {
    	this.beverages.add(new Alcohol(bevName, size, this.isWeekend()));
    }
    public boolean isWeekend()
    {
    	boolean day = false;
    	if (orderDay == Day.SATURDAY || orderDay == Day.SUNDAY) 
    	{
    		day = true;
    		return day;
    	}
    	
    	return day;
    }
    public int findNumOfBeveType(Type type)
    {
    	int total =0;
    	
    	return total;
    }
    public Beverage getBeverage(int itemNo)
    {
    	return  beverages.get(itemNo);
    }
   
    public int getOrderNumber() 
    {
        Random rand = new Random();
        int orderNumber = rand.nextInt(80001) + 10000;
        return orderNumber;
    }

    @Override
	public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
		this.beverages.add(new Coffee(bevName, size, extraShot, extraSyrup));
    }
   

    public void addNewBeverage(String name, Size size, boolean offeredInWeekend) {
        this.beverages.add(new Alcohol(name, size, offeredInWeekend));
    }

    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Order Number: ").append(orderNumber);
        sb.append(", Order Time: ").append(orderTime);
        sb.append(", Order Day: ").append(orderDay);
        sb.append(", Customer Name: ").append(customer.getName());
        sb.append(", Customer Age: ").append(customer.getAge());
        sb.append(", Beverages: ");
        for (Beverage beverage : beverages) {
            sb.append(beverage.toString()).append(", ");
        }
        sb.delete(sb.length() - 2, sb.length()); // remove last ", "
        return sb.toString();
    }

    @Override
    public int compareTo(Order other) 
    {
        return Integer.compare(orderNumber, other.orderNumber);
    }

    public int getOrderTime() 
    {
        return orderTime;
    }

    
    public Day getOrderDay() {
        return orderDay;
    }

    
    public Customer getCustomer() {
        return new Customer(customer); // return deep copy of customer
    }

    
    public List<Beverage> getBeverages() {
        return beverages;
    }
    public int getTotalItems()
    {
    	return beverages.size();
    }


	@Override
	public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein) {
		this.beverages.add(new Smoothie(bevName, size, numOfFruits, addProtein));
		
	}
}