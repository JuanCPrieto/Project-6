/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: 05/05/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan_Prieto__
*/
public class Smoothie extends Beverage
{
	
	 private static final double PROTEIN_PRICE = 1.5;
	 private static final double FRUIT_PRICE = 0.5;

	 private int numFruits;
	 private boolean proteinAdded;

	    public Smoothie(String name, Size size, int numFruits, boolean proteinAdded) 
	    {
	        super(name, Type.SMOOTHIE, size);
	        this.proteinAdded = proteinAdded;
	        this.numFruits = numFruits;
	    }

	    public int getNumFruits() {
	        return numFruits;
	    }

	    public void setNumFruits(int numFruits) {
	        this.numFruits = numFruits;
	    }

	    public boolean isProteinAdded() {
	        return proteinAdded;
	    }

	    public void setProteinAdded(boolean proteinAdded) {
	        this.proteinAdded = proteinAdded;
	    }

	    @Override
	    public String toString() {
	        String s = super.toString();
	        s += ", Protein Added: " + proteinAdded;
	        s += ", Number of Fruits: " + numFruits;
	        s += ", Price: " + calcPrice();
	        return s;
	    }

	    @Override
	    public boolean equals(Object obj) {
	        if (obj instanceof Smoothie) {
	            Smoothie other = (Smoothie) obj;
	            return super.equals(other) && proteinAdded == other.proteinAdded && numFruits == other.numFruits;
	        }
	        return false;
	    }

	    @Override
	    public double calcPrice() {
	        double price = super.getBasePrice();
	        
	        if (proteinAdded) 
	        {
	            price += PROTEIN_PRICE;
	        }
	        price += numFruits * FRUIT_PRICE;
	        return price;
	    }
	
	
}
