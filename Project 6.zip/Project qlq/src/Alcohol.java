/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: 05/05/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan_Prieto__
*/

public class Alcohol extends Beverage
{
	 private static final double WEEKEND_PRICE = 0.6;
	 private boolean offeredInWeekend;

	    public Alcohol(String name, Size size, boolean offeredInWeekend) 
	    {
	        super(name,Type.ALCOHOL, size);
	        this.offeredInWeekend = offeredInWeekend;
	    }

	    @Override
	    public String toString() 
	    {
	        String s = super.toString();
	        s += "\n" + ", Offered in Weekend: " + offeredInWeekend + ", Price: " + calcPrice();
	        return s;
	    }
	    @Override
	    public boolean equals(Object obj) 
	    {
	    	 if (this == obj) {
	    	        return true;
	    	    }
	    	    if (!(obj instanceof Alcohol)) {
	    	        return false;
	    	    }
	    	    Alcohol other = (Alcohol) obj;
	    	    if (!super.equals(other)) {
	    	        return false;
	    	    }
	    	    if (offeredInWeekend != other.offeredInWeekend) {
	    	        return false;
	    	    }
	    	    if (Double.doubleToLongBits( WEEKEND_PRICE) != Double.doubleToLongBits(other. WEEKEND_PRICE))
	    	    		{
	    	        return false;
	    	    }
	    	    return true;
	    }
	    
	    @Override
	    public double calcPrice() 
	    {
	    	double price = super.getBasePrice();
	        switch (super.getSize()) {
	            case SMALL:
	                break;
	            case MEDIUM:
	                price += super.getSizePrice();
	                break;
	            case LARGE:
	                price += 2 * super.getSizePrice();
	                break;
	        }
	        if (offeredInWeekend) {
	            price +=  WEEKEND_PRICE;
	        }
	        return price;
	    }
	    
	    public boolean isOfferedInWeekend() {
	        return offeredInWeekend;
	    }

	    public void setOfferedInWeekend(boolean offeredInWeekend) {
	        this.offeredInWeekend = offeredInWeekend;
	    }


	   
	
}
