/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: 05/05/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan_Prieto__
*/
public class Coffee extends Beverage
{
	private boolean extraShot;
	private boolean extraSyrup;
	private final double SHOT_COST = .5;
	private final double SYRUP_COST = .5;
	
	public Coffee(String n, Size s, boolean shot, boolean syrup) 
	{
		super(n, Type.COFFEE, s);
		extraShot = shot;
		extraSyrup = syrup;
	}

	    public double calcPrice() 
	    {
	        double basePrice = super.getBasePrice();
	        if (super.getSize() != Size.SMALL) 
	        {
	            basePrice += getSizePrice();
	        }
	        if (extraShot) {
	            basePrice += SHOT_COST;
	        }
	        if (extraSyrup) {
	            basePrice += SYRUP_COST;
	        }
	        return basePrice;
	    }

	    public String toString() {
	        return getSize() + " " + getName() + " Coffee " +
	               (extraShot ? "with extra shot " : "") +
	               (extraSyrup ? "with extra syrup " : "") +
	               "Price: $" + calcPrice();
	    }

	    public boolean equals(Object obj) {
	        if (this == obj) {
	            return true;
	        }
	        if (!(obj instanceof Coffee)) {
	            return false;
	        }
	        Coffee other = (Coffee) obj;
	        return super.equals(obj) &&
	               extraShot == other.extraShot &&
	               extraSyrup == other.extraSyrup;
	    }

	    public boolean getExtraShot() {
	        return extraShot;
	    }

	    public void setExtraShot(boolean extraShot) {
	        this.extraShot = extraShot;
	    }

	    public boolean getExtraSyrup() {
	        return extraSyrup;
	    }

	    public void setExtraSyrup(boolean extraSyrup) {
	        this.extraSyrup = extraSyrup;
	    }
	
	
	
	
}
