import java.util.Objects;

/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: 05/05/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan_Prieto__
*/
public abstract class Beverage 
{
    private String name;
    private Type type;
    private Size size;
    private final double BASE_PRICE = 2.0;
    private final double SIZE_PRICE = 1.0;

    public Beverage(String n, Type t, Size s)
    {
    	name = n;
    	type = t;
    	size = s;
    }
    
    public abstract double calcPrice();

    @Override
    public String toString() 
    {
        return "Name: " + name + ", type=" + type + ", Size: " + size;
    }

    @Override
    public boolean equals(Object obj) 
    {
    	if (this == obj) 
    	{
        return true;
    	}
        if (obj == null || getClass() != obj.getClass()) 
        {
            return false;
        }
        Beverage other = (Beverage) obj;
        return Objects.equals(name, other.name)
                && size == other.size
                && type == other.type;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    public Type getType() 
    {
        return type;
    }

    public void setType(Type type) 
    {
        this.type = type;
    }

    public Size getSize() 
    {
        return size;
    }

    public void setSize(Size size) 
    {
        this.size = size;
    }

    public double getBasePrice() 
    {
        return BASE_PRICE;
    }

    public double getSizePrice() 
    {
        return SIZE_PRICE;
    }
}
